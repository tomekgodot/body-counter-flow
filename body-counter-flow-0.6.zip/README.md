Body Counter Flow 0.6

Flow UX refinement: stable controls, adaptive More, richer encounter activities, fetish modal, date/rating polish.
