Body Counter Flow 0.4

Progressive MORE categories, adaptive shortcuts, wheel date pickers, larger rotary controls, stable conditional layout, refined top navigation.
